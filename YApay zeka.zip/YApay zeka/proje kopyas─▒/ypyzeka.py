# Dijkstralar için Python program
# tek kaynak en kısa
# yol algoritması.bitişiklik matrisi içindir
# grafiğin gösterimi



# Grafiği temsil eden sınıf
class Graph:

    # Bulmak için bir yardımcı program işlevi  minimum nokta değerine sahip
    # tepe noktası,
    # hala sıradaki köşe noktaları kümesi
    def minDistance(self, dist, queue):
        # Min değeri ne kadar
        minimum = float( "Inf" )
        min_index = -1

        # min değeri var
        for i in range( len( dist ) ):
            if dist[i] < minimum and i in queue:
                minimum = dist[i]
                min_index = i
        return min_index

    # En kısa yolu yazdırma işlevi katnaktan J üst diziyi kullanarak

    def printPath(self, parent, j):

        # Temel Durum: j kaynağı ise
        if parent[j] == -1:
            print()
            j,
            return
        self.printPath( parent, parent[j] )
        print
        j,

    # Oluşturulan mesafe dizisini yazdırmak için bir yardımcı program işlevi
    def printSolution(self, dist, parent):
        src = 0
        print( "Vertex \t\tDistance from Source\tPath" )
        for i in range( 1, len( dist ) ):
            print( "\n%d --> %d \t\t%d \t\t\t\t\t" % (src, i, dist[i]) ),
            self.printPath( parent, i )



    def dijkstra(self, graph, src):

        row = len( graph )
        col = len( graph[0] )

        # çıkış dizisi. dist [i] src ile i arasındaki en kısa mesafeyi koruyacaktır. Tüm mesafeleri INFINITE olarak başlat
        dist = [float( "Inf" )] * row

        # en kısa yol ağacını saklamak için üst dizi
        parent = [-1] * row

        # Kaynak tepe noktasının kendisinden uzaklığı her zaman 0'dır
        dist[src] = 0

        # tüm köşeleri sıraya ekle
        queue = []
        for i in range( row ):
            queue.append( i )

        # Tüm köşeler için en kısa yolu bulun
        while queue:

            # hala kuyrukta olan köşe kümesinden minimum tepe noktasını seçin

            u = self.minDistance( dist, queue )

            # mininmum öğeyi kaldır
            queue.remove( u )

            # Dağıtım değerini ve üst öğeyi güncelleme bitişik köşe noktalarının dizini seçilen tepe noktası.
            # Sadece düşün hala içinde olan köşe noktaları

            for i in range( col ):

                if graph[u][i] and i in queue:
                    if dist[u] + graph[u][i] < dist[i]:
                        dist[i] = dist[u] + graph[u][i]
                        parent[i] = u

                    #  inşa edilen mesafe dizisini yazdır
        self.printSolution( dist, parent )


g = Graph()

graph = [[0, 4, 0, 0, 0, 0, 0, 8, 0],
         [4, 0, 8, 0, 0, 0, 0, 11, 0],
         [0, 8, 0, 7, 0, 4, 0, 0, 2],
         [0, 0, 7, 0, 9, 14, 0, 0, 0],
         [0, 0, 0, 9, 0, 10, 0, 0, 0],
         [0, 0, 4, 14, 10, 0, 2, 0, 0],
         [0, 0, 0, 0, 0, 2, 0, 1, 6],
         [8, 11, 0, 0, 0, 0, 1, 0, 7],
         [0, 0, 2, 0, 0, 0, 6, 7, 0]
         ]

    # çözümü yazdır
g.dijkstra( graph, 0 )

